//
//  sqlitedemo-Bridging-Hader.h
//  sqlitedemo
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

#ifndef sqlitedemo_Bridging_Hader_h
#define sqlitedemo_Bridging_Hader_h

#import <sqlite3.h>

#endif /* sqlitedemo_Bridging_Hader_h */
