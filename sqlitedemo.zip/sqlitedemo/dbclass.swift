//
//  dbclass.swift
//  sqlitedemo
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class dbclass: NSObject {
    
    
    func dboperation(query:String) -> Bool {
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let dbpath :String =  path[0] as String;
        
        let fullpath = dbpath.appending("/iphone.db");
        
        print(fullpath);
        
        var status :Bool = false;
        var db: OpaquePointer? = nil;
        
        if sqlite3_open(fullpath, &db) == SQLITE_OK {
            
            var statements :OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(db, query, -1, &statements, nil) == SQLITE_OK
            {
                sqlite3_step(statements);
                status = true;
                
                
                
            }
            
            sqlite3_finalize(statements);
            
            sqlite3_close(db);
        }
        
        
        return status;
        

        
        
        
    }
    
    
    func getdata(query:String) -> [Any] {
        
        var finalarr:[Any] = [];
        
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true);
        
        let dbpath :String =  path[0] as String;
        
        let fullpath = dbpath.appending("/iphone.db");
        
        print(fullpath);
        
        var status :Bool = false;
        var db: OpaquePointer? = nil;
        
        if sqlite3_open(fullpath, &db) == SQLITE_OK {
            
            var statements :OpaquePointer? = nil;
            
            if sqlite3_prepare_v2(db, query, -1, &statements, nil) == SQLITE_OK
            {
                
                while sqlite3_step(statements) == SQLITE_ROW {
                    
                    var arr:[String] = [];
                   
                     let emp_id = String(cString: sqlite3_column_text(statements, 0))
                     let emp_name = String(cString: sqlite3_column_text(statements, 1))
                    
                     let emp_add = String(cString: sqlite3_column_text(statements, 2))
                    
                    let emp_mob = String(cString: sqlite3_column_text(statements, 3));
                    
                    arr.append(emp_id);
                    arr.append(emp_name)
                    arr.append(emp_add);
                    arr.append(emp_mob);
                    
                    finalarr.append(arr);
                    
                    
                    
                    
                }
                
                
                
            }
            
            sqlite3_finalize(statements);
            
            sqlite3_close(db);
        }
        
        
        return finalarr;

        
        
        
    }

}
