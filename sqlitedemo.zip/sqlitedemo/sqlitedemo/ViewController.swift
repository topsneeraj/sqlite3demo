//
//  ViewController.swift
//  sqlitedemo
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var arr : [Any] = [];
    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bind();
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func bind() {
        
        let obj = dbclass();
        
        let query = "select * from tblemp";
        
        arr = obj.getdata(query: query);
        
        print(arr);

        
    }
    
    @IBAction func btnclick(_ sender: Any) {
        
        
        let obj = dbclass();
        
        let query = "insert into tblemp(emp_id,emp_name,emp_add,emp_mob)values('\(txtempid.text!)','\(txtempname.text!)','\(txtempadd.text!)','\(txtempmob.text!)')";
        
        let st = obj.dboperation(query: query);
        
        
        if st == true {
            
            print("insert");
            bind();
            tbl.reloadData();
            
        }
        
        else
        {
            
            print("not");
            
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        let dic = arr[indexPath.section] as! [String];
        
        cell.textLabel?.text = dic[indexPath.row];
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        
        let dic = arr[indexPath.section] as! [String];
        
         let empid = dic[0];
        
        let query = "delete from  tblemp where emp_id = \(empid)";
        
        let obj = dbclass();
        let st  =     obj.dboperation(query: query);
       
        if st == true {
            
            arr.remove(at: indexPath.section);
            
            tableView.reloadData();
            
            
            
        }
       
        
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

